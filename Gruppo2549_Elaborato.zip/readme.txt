Setup dell'applicazione:
- Copiare l'intera cartella vsld nella directory C:\xampp\htdocs\
- Avviare il server Apache e il server MySQL in locale dal pannello di controllo di XAMPP
- Da MySQL Workbench importare il file vsld.sql
- In un browser accedere all'URL https://localhost/vsld/index.php

Credenziali da amministratore:
email: marco.buda@sus.com
password: marco

Credenziali da sviluppatore:
email: mario.rossi@sus.com
password: mario
